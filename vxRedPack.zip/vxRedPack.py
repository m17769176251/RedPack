﻿import numpy as np
from tkinter import *
from tkinter import messagebox
# from PyQt5.QtWidgets import QMainWindow, QApplication


def RedPack():
    try:
        m = float(total_money.get())
        n = int(total_number.get())
        t.delete('1.0', 'end')
        t.update()
        if m > 0 and n > 0:
            if m / n < 0.01:
                t.insert('insert', "单个红包不得低于0.01元，请重新输入！")
            elif m > 200 :
                t.insert('insert', "红包金额上限为200元，请重新输入金额！")
            elif n > 500:
                t.insert('insert', "群人数上限为500人，请重新输入分配人数！")
            else:
                if n == 1:
                    money = m
                    t.insert('insert', f'人数为1，可领到全部金额：{money}\n')
                else:
                    i = 1
                    while i < n:
                        money = np.random.uniform(0.01, 2 * m / (n - i + 1) - 0.01)  # 随机生成一[0.01,2*m/n]的红包
                        money = round(money, 2)  # 格式化输出小数点后两位数字
                        m -= money  # 当前剩余的红包金额
                        t.insert('insert', f'第{i}个人分到的红包为：{money}\n')  # 将结果添加到文本框显示
                        i += 1
                        if m == 0:
                            break
                        if i == n:
                            m = round(m, 2)
                            t.insert('insert', f'第{i}个人分到的红包为：{m}\n')
        else:
            t.delete('1.0', 'end')
            t.insert('insert', f'红包金额或人数输入错误，请重新输入！\n')
    except:
        # messagebox.showwarning('警告','红包金额或人数均为数值型，请重新输入！')
        t.delete('1.0', 'end')
        t.insert('insert','您的数据类型有误，请重新输入！')


# 根窗口创建

root = Tk()
root.title(f"抢红包")

root.geometry("500x600")
l1 = Label(root, bg='pink', text='红包总金额为：')
l1.pack()
total_money = Entry(root, width=25)
total_money.pack()
l2 = Label(root, bg='pink', text='分配人数：')
l2.pack()
total_number = Entry(root, width=25)
total_number.pack()
# root.update()
b1 = Button(root, text='分配结果', bg='pink', command=RedPack)
b1.pack()

t = Text(root,
         state='normal',
         width=30,
         height=20)
t.pack()
b2 = Button(root,
            bg='pink',
            text='退出',
            command=root.quit)
b2.pack()

root.mainloop()
